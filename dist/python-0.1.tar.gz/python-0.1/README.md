# Python
This libraruy was created as an example of a personal python package

# How To install

....